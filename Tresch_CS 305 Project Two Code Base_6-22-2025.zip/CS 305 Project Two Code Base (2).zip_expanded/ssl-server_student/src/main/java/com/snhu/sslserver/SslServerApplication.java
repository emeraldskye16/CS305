package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.security.MessageDigest;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}

@RestController
class ServerController{
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";
	@RequestMapping("/hash")
    public String myHash(){
    	String data = "Hello Emerald Tresch!";
    	try {
            // Create MessageDigest object with SHA-256 algorithm
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            // Generate hash value
            byte[] hash = digest.digest(data.getBytes());
            // Convert hash value to hexadecimal string
            String hexHash = bytesToHex(hash);
            return "Data: " + data + "<br>Algorithm: SHA-256<br>Checksum: " + hexHash;
        } catch (Exception e) {
            e.printStackTrace();
            return "Error: " + e.getMessage();
        }
    }

    // Function to convert byte array to hexadecimal string
    private static String bytesToHex(byte[] bytes) {
        StringBuilder result = new StringBuilder();
        for (byte b : bytes) {
            result.append(String.format("%02x", b));
        }
        return result.toString();
    }
}